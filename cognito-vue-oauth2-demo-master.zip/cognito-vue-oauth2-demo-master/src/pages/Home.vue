<template>
  <div class="home">
    <h1>{{ msg }}</h1>
    <a v-bind:href="url">Login</a>
  </div>

</template>

<script>

export default {
  data () {
    return {
      msg: 'Welcome',
      url: this.$auth.getLoginURL()
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
