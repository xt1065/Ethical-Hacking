export const user = state => state.user
export const auth = state => state.auth
